editArea.add_lang("eo",{
test_select:"elekto de marko",
test_but: "provo-butono"
});
