<?php
/**
  * Get an key, secret key and associate ID by Amazon fill in this content.
  * save the file to app/Config/aws.php
  */
$config = array(
  'Aws' => array(
  	'assoc' => '',    // Your Amazon Associate ID
    'key' => '',      // Your Amazon AWS Access Key ID
    'secret' => ''    // Your Amazon secret key for signature generation
  )
  );
?>