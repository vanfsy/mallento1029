<?php

	define("SMTP_HOST","ssl://smtp.gmail.com");
	define("SMTP_PORT","465");
	define("SMTP_FROM","admin@mallento.com");
	define("SMTP_PROTOCOL","SMTP_AUTH");// 'SMTP',SMTP_AUTH,POP_BEFORE
	define("SMTP_USER","admin@mallento.com");
	define("SMTP_PASS","bless-e-admin");

	define("ATTENTION_MESSAGE","入力ミスがあります");
	define('MSG_LOGIN_ERR','ユーザIDもしくはパスワードが違います');
	define('MSG_ENTRY_COMPLETE','新規登録の申請を受け付けました');

?>